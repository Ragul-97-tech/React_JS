function Header() {
    return <header><h1>React Learning Club</h1></header>
}

export default Header;